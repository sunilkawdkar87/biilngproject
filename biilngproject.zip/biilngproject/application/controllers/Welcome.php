<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
	{
		//call CodeIgniter's default Constructor
		parent::__construct();
		
		//load database libray manually
		$this->load->database();
		
		//load Model
		$this->load->model('my_model');
		$this->load->library("pagination");
	}



	public function index()
	{
		$this->load->view('include/header');
		$this->load->view('home_page');
		$this->load->view('include/footer');
	}

	public function product()
	{	
		$this->load->view('include/header');
		//Check submit button 
		 $data['message']="";
		if($this->input->post('submit'))
		{
			//this array is used to get fetch data from the view page.  
        	$data = array(  
                        'p_name'     => $this->input->post('p_name'),  
                        'p_code'  => $this->input->post('p_code'),  
                        'p_gstrate'   => $this->input->post('p_gstrate'),  
                        'seller_id' => $this->input->post('seller_id')  
                        );  
	        //insert data into database table.  
	        $this->db->insert('tb_product',$data); 

	       $data['message'] ="Records Saved Successfully"; 
		}	

		$table='tb_product';
		$config = array();
        $config["base_url"] = base_url() . "product";
        $config["total_rows"] = $this->my_model->get_count($table);
        $config["per_page"] = 10;
        $config["uri_segment"] = 2;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['products'] = $this->my_model->get_product($config["per_page"], $page,$table);

        $data['Seller']=$this->my_model->get_member('Seller');
       // $data['Purchaser']=$this->my_model->get_member('Purchaser');
       // $data['Customer']=$this->my_model->get_member('Customer');

		$this->load->view('product',$data);
		$this->load->view('include/footer');
	}

	public function member()
	{
		$this->load->view('include/header');

		//Check submit button 
		 $data['message']="";
		if($this->input->post('submit'))
		{
			//this array is used to get fetch data from the view page.  
        	$data = array(  
                        'm_name'     => $this->input->post('m_name'),  
                        'm_gstin'  => $this->input->post('m_gstin'),  
                        'm_address'   => $this->input->post('m_address'),  
                        'm_type' => $this->input->post('m_type')  
                        );  
	        //insert data into database table.  
	        $this->db->insert('tb_member',$data); 

	       $data['message'] ="Records Saved Successfully"; 
		}	

		$table='tb_member';
		$config = array();
        $config["base_url"] = base_url() . "product";
        $config["total_rows"] = $this->my_model->get_count($table);
        $config["per_page"] = 10;
        $config["uri_segment"] = 2;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['members'] = $this->my_model->get_product($config["per_page"], $page,$table);
		$this->load->view('member',$data);
		$this->load->view('include/footer');
	}

	public function purchase()
	{
		$this->load->view('include/header');
			//Check submit button 
		 $data['message']="";
		if($this->input->post('submit'))
		{
			//this array is used to get fetch data from the view page.  
			 $tr_product = $this->input->post('tr_product');
			 $tr_qty = $this->input->post('tr_qty'); 
             $tr_rate = $this->input->post('tr_rate');
             $subtotal= $tr_qty * $tr_rate;

             $gstrate  = $this->my_model->get_gstrate($tr_product);

             $gstamout= ($subtotal *$gstrate)/100;

             $total= $subtotal + $gstamout;

	        		
        	$data = array(  
                        'tr_product'     => $this->input->post('tr_product'),  
                        'tr_seller'  => $this->input->post('tr_seller'),  
                        'tr_purchaser'   => $this->input->post('tr_purchaser'), 
                        'tr_qty' => $this->input->post('tr_qty'), 
                        'tr_rate' => $this->input->post('tr_rate'),
                        'tr_GST' => $gstamout ,
                        'tr_type' => 'Purchase' ,
                        'tr_total' => $total   
                        );  
	        //insert data into database table.  
	        $this->db->insert('tb_transaction',$data); 

	       

	       $data['message'] ="Records Saved Successfully"; 
		}	

		$table='tb_transaction';
		$config = array();
        $config["base_url"] = base_url() . "purchase";
        $config["total_rows"] = $this->my_model->get_count($table);
        $config["per_page"] = 10;
        $config["uri_segment"] = 2;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['transactions'] = $this->my_model->get_purchase($config["per_page"], $page,$table);

        $data['products']=$this->my_model->get_allProduct();
        $data['Seller']=$this->my_model->get_member('Seller');
        $data['Purchaser']=$this->my_model->get_member('Purchaser');

		$this->load->view('purchase',$data);
		$this->load->view('include/footer');
	}

	public function sale()
	{
		$this->load->view('include/header');
					//Check submit button 
		 $data['message']="";
		if($this->input->post('submit'))
		{
			//this array is used to get fetch data from the view page.  
			 $tr_product = $this->input->post('tr_product');
			 $tr_qty = $this->input->post('tr_qty'); 
             $tr_rate = $this->input->post('tr_rate');
             $subtotal= $tr_qty * $tr_rate;

             $gstrate  = $this->my_model->get_gstrate($tr_product);

             $gstamout= ($subtotal *$gstrate)/100;

             $total= $subtotal+$gstamout;

	        		
        	$data = array(  
                        'tr_product'     => $this->input->post('tr_product'),  
                        'tr_seller'  => $this->input->post('tr_purchaser'),  
                        'tr_purchaser'   => $this->input->post('tr_customer'), 
                        'tr_qty' => $this->input->post('tr_qty'), 
                        'tr_rate' => $this->input->post('tr_rate'),
                        'tr_GST' => $gstamout ,
                        'tr_type' => 'Sale' ,
                        'tr_total' => $total   
                        );  
	        //insert data into database table.  
	        $this->db->insert('tb_transaction',$data); 

	       

	       $data['message'] ="Records Saved Successfully"; 
		}	

		$table='tb_transaction';
		$config = array();
        $config["base_url"] = base_url() . "purchase";
        $config["total_rows"] = $this->my_model->get_count($table);
        $config["per_page"] = 10;
        $config["uri_segment"] = 2;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['transactions'] = $this->my_model->get_sale($config["per_page"], $page,$table);

        $data['products']=$this->my_model->get_allProduct();
        //$data['Seller']=$this->my_model->get_member('Seller');
        $data['Purchaser']=$this->my_model->get_member('Purchaser');
        $data['Customer']=$this->my_model->get_member('Customer');

		$this->load->view('sale',$data);
		$this->load->view('include/footer');
	}
	
	public function stock()
	{
		$this->load->view('include/header');

		$table='tb_product';
		$config = array();
        $config["base_url"] = base_url() . "product";
        $config["total_rows"] = $this->my_model->get_count($table);
        $config["per_page"] = 10;
        $config["uri_segment"] = 2;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['products'] = $this->my_model->get_product($config["per_page"], $page,$table);


		$this->load->view('stock',$data);
		$this->load->view('include/footer');
	}

	public function stockFilter()
	{
		$table='tb_product';
		$config = array();
        $config["base_url"] = base_url() . "product";
        $config["total_rows"] = $this->my_model->get_count($table);
        $config["per_page"] = 10;
        $config["uri_segment"] = 2;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['products'] = $this->my_model->get_product($config["per_page"], $page,$table);
        $products = $this->my_model->get_product($config["per_page"], $page,$table);
        


         if(isset($_POST['tr_product'])){

             $product = $this->input->post('tr_product');
           // $date = $this->input->post('tr_date');

            $products = $this->my_model->get_filterStock($config["per_page"], $page,$table,$product);

     	  }

            $count=1;
            foreach ($products as $product): 

              $purchase = $this->my_model->get_qtyPurchase($product->p_id);
              $sale= $this->my_model->get_qtySale($product->p_id);
              $total= $this->my_model->get_qtyTotal($product->p_id);
              $stock = $purchase-$sale;

                echo "<tr>
                    <td> ".$count."</td>
                    
                    <td> ". $product->p_name."</td>
                    <td></td>
             		<td>	</td>
                    <td> ". $purchase."</td>
                    <td> ". $sale."</td>
                    <td> ". $stock ."</td>
            
                </tr>";
            $count++;  
          endforeach; 

	}
	public function transaction()
	{
		$this->load->view('include/header');

		$table='tb_transaction';
		$config = array();
        $config["base_url"] = base_url() . "purchase";
        $config["total_rows"] = $this->my_model->get_count($table);
        $config["per_page"] = 10;
        $config["uri_segment"] = 2;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['transactions'] = $this->my_model->get_product($config["per_page"], $page,$table);

        $data['products']=$this->my_model->get_allProduct();

		$this->load->view('transaction',$data);
		$this->load->view('include/footer');
	}



	public function transactionFilter()
	{
		
		$table='tb_transaction';
		$config = array();
        $config["base_url"] = base_url() . "purchase";
        $config["total_rows"] = $this->my_model->get_count($table);
        $config["per_page"] = 10;
        $config["uri_segment"] = 2;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['transactions'] = $this->my_model->get_product($config["per_page"], $page,$table);
        $transactions = $this->my_model->get_product($config["per_page"], $page,$table);
        


         if(isset($_POST['tr_product'])){

            $product = $this->input->post('tr_product');
            $date = $this->input->post('tr_date');
            $type = $this->input->post('tr_type');
           //echo "SELECT * FROM `tb_transaction` WHERE DATE(`tr_date`)='$date' and `tr_product`=$product";

           $transactions = $this->my_model->get_filter($config["per_page"], $page,$table,$product,$date,$type);

     	  }


            $sn=1; 
            foreach ($transactions as $transaction): 
               $Amt = $transaction->tr_Qty * $transaction->tr_rate; 
           echo "<tr>
                <td> ".$sn."</td>
                <td>".$transaction->tr_date."</td>
                <td>".$this->my_model->get_memberName($transaction->tr_seller)."</td>
                <td>".$this->my_model->get_memberName($transaction->tr_purchaser)."</td>
                <td>".$transaction->tr_type."</td>
                <td>".$transaction->tr_Qty."</td>
                <td>".$transaction->tr_rate."</td>
                <td>".$Amt."</td>
                <td>".$transaction->tr_GST."</td>
                <td>".$transaction->tr_total."</td>
            </tr>";
          	$sn++; 

      		endforeach;



	}

	public function stockcheck()
	{
		 if(isset($_POST['tr_product'])  ){
		 	 $tr_qty =(int) $_POST['tr_qty'];
		 	 $pid = 	$_POST['tr_product'];
			 $qtySale = $this->my_model->get_qtySale($pid);
			 $qtyPurchase = $this->my_model->get_qtyPurchase($pid);
			 $qty =$qtyPurchase - $qtySale;

			 if($qty >= $tr_qty ){
			 	echo '1';
			 }else{
			 	echo '0';
			 }
		}
			
	}


}