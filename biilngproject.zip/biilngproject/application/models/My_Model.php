<?php
class My_Model extends CI_Model 
{
	//protected $table = 'tb_product';

    public function __construct() {
        parent::__construct();
    }

    public function get_count($table) {
        return $this->db->count_all($table);
    }

    public function get_product($limit, $start,$table) {
        $this->db->limit($limit, $start);

        
        $query = $this->db->get($table);

        return $query->result();
    }

    public function get_filterStock($limit, $start,$table,$tr_product='',$date='') {
        //$this->db->limit($limit, $start);
        $str1="SELECT * FROM `".$table."`";
        $str="";
      

        if($tr_product!=""){
             $str.=" WHERE `p_id`=$tr_product";
        }

        echo  $str= $str1." ".$str;

        $query = $this->db->query("$str");   
       
        return $query->result();
     }
    public function get_filter($limit, $start,$table,$tr_product='',$date='',$tr_type='') {
        //$this->db->limit($limit, $start);
        $str1="SELECT * FROM `tb_transaction`";
        $str="";
        if($date!=""){

            if($str==""){
                $str.="WHERE DATE(`tr_date`)='$date'";
            }else{
                $str.=" AND DATE(`tr_date`)='$date'";
            }
            //$query = $this->db->query("SELECT * FROM `tb_transaction` WHERE DATE(`tr_date`)='$date' ");
        }

        if($tr_product!=""){
            if($str==""){
                $str.=" WHERE `tr_product`=$tr_product";
            }else{
                $str.=" AND `tr_product`=$tr_product";
            }
            //$query = $this->db->query("SELECT * FROM `tb_transaction` WHERE  `tr_product`=$tr_product");
        }

        if($tr_type!=""){
            if($str==""){
                $str.="WHERE `tr_type`='$tr_type'";
            }else{
                $str.=" AND `tr_type`='$tr_type'";
            }
            //$query = $this->db->query("SELECT * FROM `tb_transaction` WHERE  `tr_product`=$tr_product");
        }

        echo  $str= $str1." ".$str;

        $query = $this->db->query("$str");   
       
        return $query->result();
    }

    public function get_sale($limit, $start,$table) {
        $this->db->limit($limit, $start);
         $this->db->where('tr_type','Sale');
        $query = $this->db->get($table);

        return $query->result();
    }

    public function get_purchase($limit, $start,$table) {
        $this->db->limit($limit, $start);
         $this->db->where('tr_type','Purchase');
        $query = $this->db->get($table);

        return $query->result();
    }

    public function get_member($type) {
       
        $this->db->select("*");
        $this->db->from("tb_member");
        $this->db->where('m_type',$type);
        $query = $this->db->get();
        return $query->result();
    }

     public function get_allProduct() {
       
        $this->db->select("*");
        $this->db->from("tb_product");
        $query = $this->db->get();
        return $query->result();
    }

     public function get_gstrate($p_id) {
       
        $this->db->select("*");
        $this->db->from("tb_product");
         $this->db->where('p_id',$p_id);
        $query = $this->db->get();
        $product= $query->result();
        $gstrate = $product[0]->p_gstrate; 
        return  $gstrate;
    }

     public function get_qtyPurchase($p_id) {
       
        $query = $this->db->query("SELECT SUM(`tr_Qty`) AS Qty  FROM `tb_transaction` WHERE `tr_type`='Purchase' AND `tr_product`=$p_id");
        $Purchase= $query->result();
        $Qty = $Purchase[0]->Qty; 
        return  $Qty;
    }

    public function get_qtySale($p_id) {
       
        $query = $this->db->query("SELECT SUM(`tr_Qty`) AS Qty  FROM `tb_transaction` WHERE `tr_type`='Sale' AND `tr_product`=$p_id");
        $Sale= $query->result();
        $Qty = $Sale[0]->Qty; 
        return  $Qty;
    }

    public function get_qtyTotal($p_id) {
       
        $query = $this->db->query("SELECT SUM(`tr_Qty`) AS Qty  FROM `tb_transaction` WHERE `tr_product`=$p_id");
        $total= $query->result();
        $Qty = $total[0]->Qty; 
        return  $Qty;
    }
    
    public function get_memberName($id) {
       
        $this->db->select("*");
        $this->db->from("tb_member");
        $this->db->where('m_id',$id);
        $query = $this->db->get();
        $result=$query->result();
        $m_name = $result[0]->m_name; 
        return  $m_name;
    }
    public function get_productName($id) {
       
        $this->db->select("*");
        $this->db->from("tb_product");
        $this->db->where('p_id',$id);
        $query = $this->db->get();
        $result=$query->result();
        $p_name = $result[0]->p_name; 
        return  $p_name;
    }
}


?>