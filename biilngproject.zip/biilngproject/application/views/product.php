
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
      <h3>Product</h3>
    <hr>
      <form method="post" action="">  
         <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputName">Product Name:</label>
            <input type="text" name="p_name" class="form-control" id="inputName" placeholder="" required>
          </div>
          <div class="form-group col-md-6">
            <label for="inputCode">Product Code:</label>
            <input type="text" name="p_code" class="form-control" id="inputCode" placeholder="" required>
          </div>
        </div>
          <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputGST">Applicable GST Rate:</label>
            <input type="number" name="p_gstrate" class="form-control" id="inputGST" placeholder="" required>
          </div>
          <div class="form-group col-md-6">
            <label for="inputCode">Seller:</label>

            <?php //print_r($Seller); ?>
            <select id="inputState" name="seller_id" class="form-control" required>
              <option value="">Choose...</option>
             
              <?php foreach($Seller as $member){ ?>

                <option value="<?php echo $member->m_id; ?>" ><?php echo $member->m_name; ?></option>
              
              <?php } ?>
              
            </select>
          </div>
        </div>
        <input type="submit" name="submit" class="btn btn-primary" value="save">
        <?php if($message !="") { echo $message; }; ?>
      </form>  

      <hr> 
     <div class="column">
                <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Code</th>
                            <th>Applicable GST Rate</th>
                            <th>Seller</th>
                          
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?= $product->p_name ?></td>
                                <td><?= $product->p_code ?></td>
                                <td><?= $product->p_gstrate ?>%</td>
                                <td><?= $this->my_model->get_memberName($product->seller_id) ?></td>
                              
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <p><?php echo $links; ?></p>
            </div>
    </div>
    <div class="col-sm-2 sidenav">
    
    </div>
  </div>
</div>
