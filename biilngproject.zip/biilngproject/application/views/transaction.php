
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
      <h3>View Transaction Report</h3>
          <hr>

        <form method="post" action="" id="fillter">  
         <div class="form-row">
          <div class="form-group col-md-3">
            <label for="inputGST">Date:</label>
            <input type="date" name="tr_date" class="form-control form-control-sm" id="tr_date" placeholder="" required>
          </div>  
          <div class="form-group col-md-3">
            <label for="inputName">Product:</label>
             <select id="tr_product" name="tr_product" class="form-control form-control-sm" required>
              <option value="">Choose...</option>
               <?php foreach($products as $product){ ?>
                <option value="<?php echo $product->p_id; ?>" ><?php echo $product->p_name; ?></option>
               <?php } ?>
            </select>
          </div>
          <div class="form-group col-md-3">
            <label for="inputName">Type:</label>
             <select id="tr_type" name="tr_type" class="form-control form-control-sm" required>
              <option value="">Choose...</option>
             
                <option value="Purchase" >Purchase</option>
                  <option value="Sale" >Sale</option>
            </select>
          </div>
            <div class="form-group col-md-3 ">
            </div>
        </div>
      </form> 
      <hr> 
     <div class="column">
                <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
                    <thead>
                        <tr>
                            <th>Sr.</th>
                            <th>Date</th>
                            <th>Seller</th>
                            <th>Buyer</th>
                            <th>Type</th>
                            <th>Qty</th>
                            <th>Rate</th>
                            <th>Amt.</th>
                            <th>GST</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody id="result">
                        <?php
                            $sn=1; 
                            foreach ($transactions as $transaction): 
                               $Amt = $transaction->tr_Qty * $transaction->tr_rate; ?>
                            <tr>
                                <td><?= $sn ?></td>
                                <td><?= $transaction->tr_date ?></td>
                                <td><?= $this->my_model->get_memberName($transaction->tr_seller) ?></td>
                                <td><?= $this->my_model->get_memberName($transaction->tr_purchaser) ?></td>
                                <td><?= $transaction->tr_type ?></td>
                                <td><?= $transaction->tr_Qty ?></td>
                                <td><?= $transaction->tr_rate ?></td>
                                <td><?=  $Amt ?></td>
                                <td><?= $transaction->tr_GST ?></td>
                                <td><?= $transaction->tr_total ?></td>
                            </tr>
                        <?php  $sn++; endforeach; ?>
                    </tbody>
                </table>
                <p><?php echo $links; ?></p>
            </div>
    </div>
    <div class="col-sm-2 sidenav">
    
    </div>
  </div>
</div>
<script>
$(document).ready(function(e) {
   $('select[name="tr_product"]').on('change', function() {
    var url = "http://localhost/biilngproject/transactionFilter";
    $.ajax({
      type: "POST",
      url: url,
      data: $("#fillter").serialize(),
      success: function(data) {
       $('#result').html(data);
      }
    });
  });

  $('#tr_date').on('change', function() {
    var url = "http://localhost/biilngproject/transactionFilter";
    $.ajax({
      type: "POST",
      url: url,
      data: $("#fillter").serialize(),
      success: function(data) {
       $('#result').html(data);
      }
    });
  });
   $('#tr_type').on('change', function() {
    var url = "http://localhost/biilngproject/transactionFilter";
    $.ajax({
      type: "POST",
      url: url,
      data: $("#fillter").serialize(),
      success: function(data) {
       $('#result').html(data);
      }
    });
  });

   
});
</script>
