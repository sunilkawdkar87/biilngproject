
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
      <h3>Member</h3>
    <hr>
      <form method="post" action="">  
         <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputName">Name:</label>
            <input type="text" name="m_name" class="form-control" id="inputName" placeholder="" required>
          </div>
          <div class="form-group col-md-6">
            <label for="inputCode">GSTIN:</label>
            <input type="text" name="m_gstin" class="form-control" id="inputGSTIN" placeholder="" required>
          </div>
        </div>
          <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputGST">Address:</label>
            <input type="text" name="m_address" class="form-control" id="inputAddress" placeholder="" required>
          </div>
          <div class="form-group col-md-6">
            <label for="inputCode">Member Type:</label>
            <select id="inputState" name="m_type" class="form-control" required>
              <option  value="">Choose...</option>
              <option value="Seller" >Seller</option>
              <option value="Purchaser" >Purchaser</option>
              <option value="Customer" >Customer</option>
            </select>
          </div>
        </div>
        <input type="submit" name="submit" class="btn btn-primary" value="save">
        
        <?php if($message !="") { echo $message; }; ?>
      </form>  

      <hr> 
     <div class="column">
                <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                          
                            <th>Address</th>
                              <th>GSTIN</th>
                            <th>Type</th>
                          
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($members as $member): ?>
                            <tr>
                               <td><?= $member->m_id ?></td> 
                                <td><?= $member->m_name ?></td>
                                <td><?= $member->m_address ?></td>
                                <td><?= $member->m_gstin ?></td>
                                <td><?= $member->m_type ?></td>
                              
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <p><?php echo $links; ?></p>
            </div>
    </div>
    <div class="col-sm-2 sidenav">
    
    </div>
  </div>
</div>
