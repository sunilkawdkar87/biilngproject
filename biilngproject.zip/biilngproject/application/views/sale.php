
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
      <h3>Sale  Bill</h3>
    <hr>
        <form method="post" action="" id="addsale">  
         <div class="form-row">
          <div class="form-group col-md-4">
            <label for="tr_product">Product:</label>
             <select id="tr_product" name="tr_product" class="form-control" required>
              <option value="">Choose...</option>
               <?php foreach($products as $product){ ?>
                <option value="<?php echo $product->p_id; ?>" ><?php echo $product->p_name; ?></option>
               <?php } ?>
            </select>
           
          </div>
         
            <div class="form-group col-md-4">
            <label for="inputGST">Purchaser:</label>
            <select id="inputState" name="tr_purchaser" class="form-control" required>
              <option value="">Choose...</option>
                <?php foreach($Purchaser as $member){ ?>
                <option value="<?php echo $member->m_id; ?>" ><?php echo $member->m_name; ?></option>
               <?php } ?>
            </select>
          </div>
           <div class="form-group col-md-4">
            <label for="inputCode">Customer:</label>
             <select id="inputState" name="tr_customer" class="form-control" required>
              <option value="">Choose...</option>
                <?php foreach($Customer as $member){ ?>
                <option value="<?php echo $member->m_id; ?>" ><?php echo $member->m_name; ?></option>
               <?php } ?>
            </select>
          </div>
        </div>
        <div class="form-row">
        
          <div class="form-group col-md-4">
            <label for="inputGST">Qty:</label>
            <input type="number" name="tr_qty" class="form-control" id="tr_qty" placeholder="" required>
            <span id="error"></span> 
          </div>
         <div class="form-group col-md-4">
            <label for="inputGST">Rate:</label>
            <input type="number" name="tr_rate" class="form-control" id="tr_rate" placeholder="" required>
          </div>

        

        </div>
        <input type="submit" name="submit" class="btn btn-primary" value="save">
         
        <?php if($message !="") { echo $message; }; ?>
      </form> 

      <hr> 
     <div class="column">
                <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
                    <thead>
                        <tr>
                             <th> ID</th> 
                            <th>Product</th>
                            <th>Purchaser</th>
                            <th>Customer</th>
                            <th>Rate</th>
                            <th>GST</th>
                            <th>Total</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transactions as $transaction): ?>
                            <tr>
                               <td><?= $transaction->tr_id ?></td>
                                <td><?= $this->my_model->get_productName($transaction->tr_product) ?></td>
                                
                                <td><?= $this->my_model->get_memberName($transaction->tr_purchaser) ?></td>
                                <td><?= $this->my_model->get_memberName($transaction->tr_seller) ?></td>
                                <td><?= $transaction->tr_rate ?></td>
                                <td><?= $transaction->tr_GST ?></td>
                                <td><?= $transaction->tr_total ?></td>
                                <td><?= $transaction->tr_date ?></td>
                        
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <p><?php echo $links; ?></p>
            </div>
    </div>
    <div class="col-sm-2 sidenav">
    
    </div>
  </div>
</div>



<script type="text/javascript">


    $(document).ready(function() {
  

         $("#tr_qty").on("keyup", function() {

            var url = "http://localhost/biilngproject/stockcheck";
            $.ajax({
              type: "POST",
              url: url,
              data: $("#addsale").serialize(),
              success: function(data) {
               if(data== '0'){ 
                $('#error').html('Quntis not available for sale');
                 $(":submit").attr("disabled", true);
                }else{
                      $('#error').html('');
                      $(":submit").removeAttr("disabled");
                }
              }
            });
          });
            $("#tr_product").on("change", function() {

            var url = "http://localhost/biilngproject/stockcheck";
            $.ajax({
              type: "POST",
              url: url,
              data: $("#addsale").serialize(),
              success: function(data) {
               if(data== '0'){ 
                $('#error').html('Quntis not available for sale');
                 $(":submit").attr("disabled", true);
                }else{
                      $('#error').html('');
                      $(":submit").removeAttr("disabled");
                }
              }
            });
          });
    });
</script>