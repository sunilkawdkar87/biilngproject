
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
      <h3>View Stock Report</h3>
        <hr> 
       <form method="post" action="" id="fillter">  
         <div class="form-row">
          <div class="form-group col-md-3">
            <label for="inputGST">Date:</label>
            <input type="date" name="tr_date" class="form-control form-control-sm" id="tr_date" placeholder="" required>
          </div>  
          <div class="form-group col-md-3">
            <label for="inputName">Product:</label>
             <select id="tr_product" name="tr_product" class="form-control form-control-sm" required>
              <option value="">Choose...</option>
               <?php foreach($products as $product){ ?>
                <option value="<?php echo $product->p_id; ?>" ><?php echo $product->p_name; ?></option>
               <?php } ?>
            </select>
          </div>
        
            <div class="form-group col-md-6 ">
            </div>
        </div>
      </form> 
      <hr> 
     <div class="column">
                <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
                    <thead>
                        <tr>
                            <th>Sr</th>
                            
                            <th>Product </th>
                            <th>Opening </th>
                            <th>Qty </th>
                            <th>Purchase </th>
                            <th>Sale </th>
                            <th>Stock</th>
                        </tr>
                    </thead>
                    <tbody id="result">
                        <?php 
                        $count=1;
                        foreach ($products as $product): 
                          $purchase = $this->my_model->get_qtyPurchase($product->p_id);
                          $sale= $this->my_model->get_qtySale($product->p_id);
                          $total= $this->my_model->get_qtyTotal($product->p_id);
                          $stock = $purchase-$sale;
                       ?>

                            <tr>
                                <td><?= $count ?></td>
                                
                                <td><?= $product->p_name ?></td>
                                <td></td>
                                <td></td>
                                <td><?= $purchase ?></td>
                                <td><?= $sale ?></td>
                                <td><?= $stock ?></td>
                        
                            </tr>
                        <?php $count++;  endforeach; ?>
                    </tbody>
                </table>
                <p><?php echo $links; ?></p>
            </div>
    </div>
    <div class="col-sm-2 sidenav">
    
    </div>
  </div>
</div>
<script>
$(document).ready(function(e) {
   $('select[name="tr_product"]').on('change', function() {
    var url = "http://localhost/biilngproject/stockFilter";
    $.ajax({
      type: "POST",
      url: url,
      data: $("#fillter").serialize(),
      success: function(data) {
       $('#result').html(data);
      }
    });
  });

  $('#tr_date').on('change', function() {
    var url = "http://localhost/biilngproject/stockFilter";
    $.ajax({
      type: "POST",
      url: url,
      data: $("#fillter").serialize(),
      success: function(data) {
       $('#result').html(data);
      }
    });
  });
  

   
});
</script>