
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
      <h3>Purchase Bill</h3>
    <hr>
      <form method="post" action="">  
         <div class="form-row">
          <div class="form-group col-md-4">
            <label for="inputName">Product:</label>
             <select id="inputState" name="tr_product" class="form-control" required>
              <option value="">Choose...</option>
               <?php foreach($products as $product){ ?>
                <option value="<?php echo $product->p_id; ?>" ><?php echo $product->p_name; ?></option>
               <?php } ?>
            </select>
          </div>
          <div class="form-group col-md-4">
            <label for="inputCode">Seller:</label>
             <select id="inputState" name="tr_seller" class="form-control" required>
              <option value="">Choose...</option>
                <?php foreach($Seller as $member){ ?>
                <option value="<?php echo $member->m_id; ?>" ><?php echo $member->m_name; ?></option>
               <?php } ?>
            </select>
          </div>
            <div class="form-group col-md-4">
            <label for="inputGST">Purchaser:</label>
            <select id="inputState" name="tr_purchaser" class="form-control" required>
              <option value="">Choose...</option>
                <?php foreach($Purchaser as $member){ ?>
                <option value="<?php echo $member->m_id; ?>" ><?php echo $member->m_name; ?></option>
               <?php } ?>
            </select>
          </div>
        </div>
        <div class="form-row">
        
          <div class="form-group col-md-4">
            <label for="inputGST">Qty:</label>
            <input type="text" name="tr_qty" class="form-control" id="inputAddress" placeholder="" required>
          </div>
         <div class="form-group col-md-4">
            <label for="inputGST">Rate:</label>
            <input type="text" name="tr_rate" class="form-control" id="inputAddress" placeholder="" required>
          </div>

        
          
         <!-- <div class="form-group col-md-3">
            <label for="inputGST">GST :</label>
            <input type="text" name="tr_GST" class="form-control" id="inputAddress" placeholder="" required readonly> 
          </div>
          <div class="form-group col-md-3">
            <label for="inputGST">Total:</label>
            <input type="text" name="tr_total" class="form-control" id="inputAddress" placeholder="" required readonly>
          </div> -->

        </div>
        <input type="submit" name="submit" class="btn btn-primary" value="save">
        
        <?php if($message !="") { echo $message; }; ?>
      </form>  

      <hr> 
     <div class="column">
                <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
                    <thead>
                        <tr>
                            <th>Purchase ID</th> 
                            <th>Product</th>
                            <th>Seller</th>
                            <th>Purchaser</th>
                            <th>Qty</th>
                            <th>Rate</th>
                            <th>GST</th>
                            <th>Total</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transactions as $transaction): ?>
                            <tr>
                                <td><?= $transaction->tr_id ?></td>
                                <td><?= $this->my_model->get_productName($transaction->tr_product) ?></td>
                                <td><?= $this->my_model->get_memberName($transaction->tr_seller) ?></td>
                                <td><?= $this->my_model->get_memberName($transaction->tr_purchaser) ?></td>
                                <td><?= $transaction->tr_Qty ?></td>
                                <td><?= $transaction->tr_rate ?></td>
                                <td><?= $transaction->tr_GST ?></td>
                                <td><?= $transaction->tr_total ?></td>
                                <td><?= $transaction->tr_date ?></td>
                        
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <p><?php echo $links; ?></p>
            </div>
    </div>
    <div class="col-sm-2 sidenav">
    
    </div>
  </div>
</div>
