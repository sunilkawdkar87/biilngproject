<?php
if($user_data['lat'] !="" && $user_data['lon'] !=""){

	 $lat = $user_data['lat'] ;

	 $lon = $user_data['lon'];
	
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => 'https://api.geoapify.com/v1/routematrix?apiKey=3df066be001c47ea967954c1ed3491c3',
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => '',
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 0,
	  CURLOPT_FOLLOWLOCATION => true,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => 'POST',
	  CURLOPT_POSTFIELDS =>'{"mode":"drive","sources":[{"location":[3.4284023,6.4304377]}],"targets":[{"location":['.$lat.','.$lon.']}]}',
	  CURLOPT_HTTPHEADER => array(
		'Content-Type: application/json'
	  ),
	));

	$response = curl_exec($curl);

	curl_close($curl);
	//echo $response;

}
?>


<div class="row-fluid member_results level_<?php echo $user_data['subscription_id'];?> search_result clearfix">
    <div class="grid_element">
        <div class="img_section col-xs-2 nopad">
            <a title="<?php echo $user_data['full_name'];?> - <?php echo ucwords($w['profession'])?>" href="/<?php echo $user_data['filename']?>">
				<?php if (!empty($w['lazy_load_images'])) { ?>
				<img class="search_result_image img-rounded center-block lazyloader" loading="auto" width="400" height="400" alt="<?php echo $user_data['full_name'];?>" data-src="<?php echo $user['image_main_file']?>">
				<?php } else { ?>
				<img class="search_result_image img-rounded center-block" loading="auto" width="400" height="400" alt="<?php echo $user_data['full_name'];?>" src="<?php echo $user['image_main_file']?>" />
				<?php } ?>   
            </a>
			     
        </div>
        <div class="mid_section col-xs-10 col-sm-7 norpad">
            <?php
            $addonFavorites = getAddOnInfo("add_to_favorites","a8ad175dd81204563b3a9fc3ebcd5354");
            if (isset($addonFavorites['status']) && $addonFavorites['status'] === 'success') {
                      echo '<span class="postItem" data-userid="'.$user_data['user_id'].'" data-datatype="10" data-dataid="10" data-postid="0"></span>';
                      echo widget($addonFavorites['widget'],"",$w['website_id'],$w);
            }

            ?>
			
			
            <a class="center-block" title="<?php echo $user_data['full_name']?>" href="/<?php echo $user_data['filename']?>">
                <span class="h3 bold inline-block nomargin member-search-full-name">
                    <?php echo $user_data['full_name']?>
                </span>
                <?php if ($user_data['company'] != "" && $user_data['listing_type'] == "Individual") { ?>
                    <span class="hidden-xs inline-block member-search-company">
                        <?php echo $user_data['company']?>
                    </span>
                <?php } ?>
            </a>
			<div class="clearfix fpad-sm nobpad"></div>
			
			<div class="distance" style="float: right;font-size: 12px;">
				<i class="glyphicon glyphicon-map-marker"></i> Distance: <span> </span> 
			</div>
			
			    
			           
			
			<?php if ($exact != "") { ?>
			<div class="hidden-sm hidden-md hidden-lg center-block small line-height-xl talign mobile-distance-within">
				<?php echo $exact ?>
			</div>
			<div class="clearfix fpad-sm nobpad"></div>
			
			
			<?php } if ($user_data['verified'] == "1") { ?>
			<div title="%%%verified_badge_content%%%" class="btn-xs alert-success bold nopad nolpad rmargin inline-block member-search-verified align-middle">
				<span class="btn-xs novpad bg-success pull-left" style="border-radius: 3px 0 0 3px;">
					<i class="fa fa-check"></i>
				</span>
				<span class="btn-xs novpad">
					%%%search_results_verified_member%%%
				</span>
			</div>
			<?php } if ($totalreviews > 0 && (in_array($reviewId['data_id'], $subscription['data_settings'])) == 1 && $subscription['hide_reviews_rating_options'] == 0) { ?>
			<div class="bold member-search-reviews inline-block rmargin align-middle small">
				<?php echo $rating['stars']?>
			</div>
			<?php } ?>
			<div class="clearfix fpad-sm nobpad"></div>
			<?php
			if ($w['member_position_in_results'] == "1" && $user_data['position'] != '') { ?>
			<p class="small nomargin member_position_in_results">
				<b class="line-height-xl">%%%search_results_position_label%%%</b> <?php echo $user_data['position']?>
			</p>
			<?php } ?>			
            <?php 
            if ($w['top_category_in_results'] == "1" && $user_data['profession_name'] != '') { ?>
                <p class="small nomargin top_category_in_results">
                    <b class="line-height-xl">%%%search_results_category_label%%%</b> <?php echo $user_data['profession_name']?>
                </p>
            <?php } ?>
            <?php if ($w['sub_category_in_results'] == "1"){
			$memberSubCategories = getMemberSubCategory($user_data['user_id'],"all","settings",intval($w['profile_services_display_limit']),"text");
			if ($memberSubCategories != "") { ?>
					<p class="small nomargin sub_category_in_results">
						<b class="line-height-xl">%%Service%%:</b> <?php echo $memberSubCategories;?>
					</p>
			<?php } }
            if ($user_data['search_description'] != "") { ?>				
				<p class="small nomargin member-search-description">
					<?php
						$user_data['search_description'] = bdString::prepareSpecialCharacter($user_data['search_description']);
						echo (preg_replace('#<[^>]+>#', ' ', $user_data['search_description']));
					?>
				</p>
            <?php }
			else if ($user_data['about_me'] !="" && $subscription['show_about_tab'] != 0 ) { ?>
				<p class="small nomargin member-search-description">
					<?php
						$user_data['about_me'] = bdString::prepareSpecialCharacter($user_data['about_me']);
						echo limitWords(preg_replace('#<[^>]+>#', ' ', $user_data['about_me']),170);
					?>
				</p>
			<?php }
            if (($user_data['city'] != '' || $user_data['state_ln'] !='' || $user_data['zip_code']!="" || $user_data['country_ln'] != '') && $subscription['profile_layout'] == "1") { ?>
                <div class="clearfix fpad-sm nobpad"></div>
                <span class="member-search-location rmargin">
                <i class="fa fa-map-marker text-danger"></i>
					<small>
						<?php if ($user_data['city'] != '') {
							echo $user_data['city'];
						}

						if ($user_data['state_ln'] != '') {

							if ($user_data['city'] != '') {
								echo ', ';
							}
							echo $user_data['state_ln'];
						}

						if ($user_data['zip_code'] != '') {

							if ($user_data['state_ln'] != '' || $user_data['city'] != '') {
								echo ', ';
							}						
							echo '<span class="inline-block">' . $user_data['zip_code'] . '</span>';

						}

						if  ($user_data['country_ln'] != "") {

							if ($user_data['state_ln'] != '' || $user_data['city'] != '' || $user_data['zip_code'] != '') {
								echo ', ';
							}
							echo '<span class=inline-block>' . $user_data['country_ln'] . '</span>';
						}
					echo '</small></span>';
            } ?>
        </div>
        <div class="info_section hidden-xs col-sm-3 norpad">
            <div class="module nomargin fpad text-center">
                <?php if ($user['nationwide']==1 && $label[serves_this_area] !="") { ?>
                    <div class="alert alert-success fpad-sm bmargin">
                        <i class="fa fa-map-marker"></i>
                        %%%serves_this_area%%%
                    </div>
                <?php } else if ($exact != "" && $distance != "") {
                    if ($exact != "") { echo $exact; } ?>
                    <div class="clearfix bpad"></div>
                <?php }
                $badgesAddOn = getAddOnInfo('member_listing_badges','4bfd736fb96d71876957b942d0293b1a');
                if ($subscription['category_badge'] != "" && isset($badgesAddOn['status']) && $badgesAddOn['status'] == 'success') {
                    echo widget($badgesAddOn['widget'],"",$w['website_id'],$w);
                }

                if (($user_data['service_area'] > 0 || $user_data['area_id_big_location'] > 0 || ($user_data['service_distance'] != "" && $user_data['service_distance'] <=  $w['default_radius'])) && $user['nationwide'] != 1 && $label[serves_this_area] !="") { ?>
                    <div class="alert alert-success fpad-sm bmargin">
                        <i class="fa fa-map-marker"></i>
                        %%%serves_this_area%%%
                    </div>
                <?php } ?>
                <a class="btn btn-sm btn-success btn-block bold search_view_listing_button" href="/<?php echo $user_data['filename']?>">%%%view_listing_label%%%</a>
                <?php if ($subscription['receive_messages'] != 1){ ?>
                    <div class="clearfix fpad-sm nobpad"></div>
                    <a class="btn btn-sm btn-primary btn-block bold search_contact_now_button" href="/<?php echo $user_data['filename']?>/connect">%%%contact_now_label%%%</a>
					<div class="clearfix"></div>
                <?php } 
					$membersOnly = addonController::isAddonActive('members_only');

					if (
							$user['phone_number'] != "" && 
							$subscription['show_phone'] == 1 && 
							( 
								$membersOnly  === false  || ($membersOnly === true && ($_COOKIE['useractive'] == 2 && isset($_COOKIE['userid']) || (!isset($_COOKIE['userid']) && strpos($subscription['membership_restriction'], "profile_pages") === false) ) ) 
							) 
						) {
						$clickPhoneAddOnLoop = getAddOnInfo("click_to_phone","1c75909cfae116e22fd25f087d8d4f7b");
						$statisticsAddOn = getAddOnInfo("user_statistics_addon","79c260ec6118524a0dea65acd7759ebe");
						if(isset($clickPhoneAddOnLoop['status']) && $clickPhoneAddOnLoop['status'] === 'success'){
							echo widget($clickPhoneAddOnLoop['widget'],"",$w['website_id'],$w);
						} else if (isset($statisticsAddOn['status']) && $statisticsAddOn['status'] === 'success') {
							echo widget($statisticsAddOn['widget'],"",$w['website_id'],$w);
						} else { ?>
							<div class="clearfix fpad-sm nobpad"></div>
							<span class="btn-default btn-sm bold text-center nohpad btn-block nomargin member-search-phone">
								%%%show_phone_number_icon%%%
								<?php echo $user['phone_number']; ?>
							</span>
						<?php }
					}				
				?>
            </div>
        </div>
    </div>
</div>
<div class="clearfix"></div>
<hr>
<?php echo widget("Bootstrap Theme - Google Pins Locations","",$w['website_id'],$w); ?>