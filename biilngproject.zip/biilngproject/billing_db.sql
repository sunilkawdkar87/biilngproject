-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2023 at 07:59 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `billing_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_member`
--

CREATE TABLE `tb_member` (
  `m_id` int(11) NOT NULL,
  `m_name` varchar(255) NOT NULL,
  `m_address` varchar(255) NOT NULL,
  `m_gstin` varchar(255) NOT NULL,
  `m_type` varchar(255) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_member`
--

INSERT INTO `tb_member` (`m_id`, `m_name`, `m_address`, `m_gstin`, `m_type`, `add_date`) VALUES
(6, 'Seller Member', 'Akshya Nagar 1st Block 1st Cross, Rammurthy nagar, Bangalore-560016', 'GST-87687', 'Seller', '2023-07-24 12:55:25'),
(7, 'Purchaser Member', 'Cecilia Chapman 711-2880 Nulla St. Mankato Mississippi 96522 (257) 563-7401', 'GST-7654', 'Purchaser', '2023-07-24 12:58:05'),
(8, 'Customer Member', 'Iris Watson P.O. Box 283 8562 Fusce Rd. Frederick Nebraska 20620 (372) 587-233', 'GST-85644', 'Customer', '2023-07-24 12:58:53');

-- --------------------------------------------------------

--
-- Table structure for table `tb_product`
--

CREATE TABLE `tb_product` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_code` varchar(255) NOT NULL,
  `p_gstrate` varchar(255) NOT NULL,
  `seller_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_product`
--

INSERT INTO `tb_product` (`p_id`, `p_name`, `p_code`, `p_gstrate`, `seller_id`) VALUES
(14, 'Product', 'Product0001', '10', 6),
(15, 'Product 2', 'Product0002', '14', 6),
(16, 'Product 3', 'Product0003', '10', 6);

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaction`
--

CREATE TABLE `tb_transaction` (
  `tr_id` int(11) NOT NULL,
  `tr_product` int(11) NOT NULL,
  `tr_seller` int(11) NOT NULL,
  `tr_purchaser` int(11) NOT NULL,
  `tr_Customer` int(11) NOT NULL,
  `tr_rate` varchar(255) NOT NULL,
  `tr_GST` varchar(255) NOT NULL,
  `tr_type` varchar(255) NOT NULL,
  `tr_total` varchar(255) NOT NULL,
  `tr_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `tr_Qty` varchar(255) NOT NULL,
  `tr_Amt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_transaction`
--

INSERT INTO `tb_transaction` (`tr_id`, `tr_product`, `tr_seller`, `tr_purchaser`, `tr_Customer`, `tr_rate`, `tr_GST`, `tr_type`, `tr_total`, `tr_date`, `tr_Qty`, `tr_Amt`) VALUES
(9, 14, 6, 7, 0, '25', '25', 'Purchase', '275', '2023-07-24 18:23:15', '10', ''),
(14, 14, 7, 8, 0, '13', '3.9', 'Sale', '42.9', '2023-07-24 18:37:45', '3', ''),
(15, 15, 6, 7, 0, '25', '17.5', 'Purchase', '142.5', '2023-07-24 18:48:21', '5', ''),
(16, 16, 6, 7, 0, '20', '10', 'Purchase', '110', '2023-07-24 18:48:37', '5', ''),
(17, 14, 7, 8, 0, '28', '19.6', 'Sale', '215.6', '2023-07-25 17:07:44', '7', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_member`
--
ALTER TABLE `tb_member`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `tb_product`
--
ALTER TABLE `tb_product`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `tb_transaction`
--
ALTER TABLE `tb_transaction`
  ADD PRIMARY KEY (`tr_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_member`
--
ALTER TABLE `tb_member`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_product`
--
ALTER TABLE `tb_product`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tb_transaction`
--
ALTER TABLE `tb_transaction`
  MODIFY `tr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
